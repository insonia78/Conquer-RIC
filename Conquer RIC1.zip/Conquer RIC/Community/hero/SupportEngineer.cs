﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Community
{
    public partial class SupportEngineer : Hero
    {
        public SupportEngineer()
        {
            //Init();
        }

        private void Init()
        {
            /*
             * TODO:
             * initialize with custom stats,
             * pictures, and gender.
             */
        }
    }
}