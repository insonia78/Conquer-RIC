﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Media;
//using System.Windows.Media.Imaging;

//namespace GameBoard
//{
//    class Warrior : Hero
//    {
//        public Warrior(int r, int c, int charSpeed) : base(r, c, charSpeed)
//        {
//            row = r;
//            col = c;
//            hp = 10;
//            moveSpeed = charSpeed;
//            characterPicture = new BitmapImage(new Uri("Male_Software_Engineer.png", UriKind.Relative));
//        }
//    }
//}